package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Userbean;

import com.controller.Commonconnection;
import com.dao.Createprofiledao;

public class Createprofile extends HttpServlet{
Connection c;
	
	ResultSet rs=null;
	PreparedStatement ps=null;
	String str=null;
	RequestDispatcher rd=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			 c=Commonconnection.getCon();
			 Userbean bean=new Userbean();
		response.setContentType("text/html");
	
		String id1=request.getParameter("username");
		String password1=request.getParameter("password");
		String role=request.getParameter("role1");
	
		bean.setUserName(id1);
		bean.setPassWord(password1);
	bean.setRoleCode(role);
	Createprofiledao obj=new Createprofiledao();
	obj.addUser(bean);
    	//System.out.println("Added one user into database");
		
		}
		catch (Exception e) {
			
			e.printStackTrace();
		} 
	}
	}
